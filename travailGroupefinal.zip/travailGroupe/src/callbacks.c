#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"
#include "string.h"
#include "reclamation.h"
#include "hebergement.h"
#include "utilisateur.h"



int radiobutt;
int t,m,d,f;
void
on_MHbutton_ajoute_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *max;
GtkWidget *min;
GtkWidget *combobox;
GtkWidget *id;
GtkWidget *gaara;
GtkWidget *numero;
GtkWidget *output;
char id1[100];
date d;
int max0 ;
char max1[100];
char min1[100];
int min0 ;
int gaara1 ;
char marque[100] ;
cap c;
char msg[100]="";
int numero0 ;
char numero1 [100];
int i;
char ch [100];
fenetre_ajout = lookup_widget (button, "MHajoutcapteur");
id = lookup_widget (button, "MHentryajoutID");
max = lookup_widget (button, "entryajoutmax");
gaara = lookup_widget (button, "spinbutton1");
numero = lookup_widget (button, "entryajoutnumero");
jour = lookup_widget (button, "spinbutton2");
mois = lookup_widget (button, "spinbutton3");
annee = lookup_widget (button, "spinbutton4");
min = lookup_widget (button, "entryajoutmin");
combobox = lookup_widget (button, "comboboxentry1");
d.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
d.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
d.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
sprintf(max1,"%d",max0);
sprintf(min1,"%d",min0);
sprintf(numero1,"%d",numero0);
strcpy(max1, gtk_entry_get_text(GTK_ENTRY(max)));
strcpy(min1, gtk_entry_get_text(GTK_ENTRY(min)));
strcpy(numero1, gtk_entry_get_text(GTK_ENTRY(numero)));
gaara1=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(gaara));
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(marque, gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
radio(radiobutt,msg);
max0=atoi(max1);
min0=atoi(min1);
numero0=atoi(numero1);
c.d.j=d.j;
c.d.m=d.m;
c.d.a=d.a;
c.max=max0;
c.min=min0;
c.numero= numero0;
strcpy(c.id,id1);
strcpy(c.type,msg);
strcpy(c.marque,marque);
c.gaara=gaara1;
i = chercher_capteur(id1);
if (i == 1)
{
output= lookup_widget (button, "MHverfaj");
strcpy(ch," le capteur existe  ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
output= lookup_widget (button, "MHverfaj");
strcpy(ch,"ajoutation effectuee avec succees");
gtk_label_set_text(GTK_LABEL(output),ch);
ajoute_capteur(c);
}
}



void
on_MHbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id ;
GtkWidget *output ;
char id1[100];
int c ;
char ch [100];
id= lookup_widget (button, "MHentryIsupprimerD");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
c = chercher_capteur(id1);
if (c == 1) 
{
output= lookup_widget (button, "MHlabelsupp");
strcpy(ch,"suppression effectuee avec succees");
gtk_label_set_text(GTK_LABEL(output),ch);
supprimer_capteur(id1);
}
else 
{
output= lookup_widget (button, "MHlabelsupp");
strcpy(ch," le capteur n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);

}
}


void
on_MHbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modifier;
GtkWidget *jour;
GtkWidget *marque;
GtkWidget *type;
GtkWidget *output;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *max;
GtkWidget *min;
GtkWidget *combobox;
GtkWidget *idnv;
GtkWidget *numero;
GtkWidget *idold;
GtkWidget *gaara;
char ch[100];
char idold1[100];
char idnv1[100];
date d;
int max0 ;
char max1[100];
char min1[100];
int min0 ;
char numero1[100];
int numero0;
int gaara1 ;
char marque1[100] ;
char type1[100] ;
cap c;
fenetre_modifier = lookup_widget (button, "MHmodifiercapteur");
idnv = lookup_widget (button, "entrymofidiernouvid");
idold = lookup_widget (button, "MHentrymodifierID");
numero = lookup_widget (button, "entrymodifiernumero");
max = lookup_widget (button, "entrymodifiermax");
gaara = lookup_widget (button, "spinbutton8");
jour = lookup_widget (button, "spinbutton5");
mois = lookup_widget (button, "spinbutton6");
annee = lookup_widget (button, "spinbutton7");
min= lookup_widget (button, "entrymodifiermin");
marque = lookup_widget (button, "MHentrymarque");
type = lookup_widget (button, "MHentrytype");
d.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
d.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
d.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
sprintf(max1,"%d",max0);
sprintf(min1,"%d",min0);
sprintf(numero1,"%d",numero0);
strcpy(max1, gtk_entry_get_text(GTK_ENTRY(max)));
strcpy(min1, gtk_entry_get_text(GTK_ENTRY(min)));
strcpy(marque1, gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(type1, gtk_entry_get_text(GTK_ENTRY(type)));
strcpy(numero1, gtk_entry_get_text(GTK_ENTRY(numero)));
gaara1=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(gaara));
strcpy(idnv1, gtk_entry_get_text(GTK_ENTRY(idnv)));
strcpy(idold1, gtk_entry_get_text(GTK_ENTRY(idold)));
max0=atoi(max1);
min0=atoi(min1);
numero0=atoi(numero1);
c.d.j=d.j;
c.d.m=d.m;
c.d.a=d.a;
c.max=max0;
c.numero=numero0;
c.min=min0;
strcpy(c.id,idnv1);
strcpy(c.type,type1);
strcpy(c.marque,marque1);
c.gaara=gaara1;
if ( ( ( strcmp (c.type,"temperature") == 0 )  ||(strcmp(c.type,"debit'd'eau")==0)||(strcmp(c.type,"fumee")==0)||(strcmp(c.type,"mouvement")==0)|| (strcmp(c.type,"TEMPERATURE")==0)||(strcmp(c.type,"DEBIT'D'EAU")==0)||(strcmp(c.type,"FUMEE")==0)||(strcmp(c.type,"MOUVEMENT")==0))&& ( (strcmp(c.marque,"MSA")==0) ||(strcmp(c.marque,"HITEC")==0)||(strcmp(c.marque,"ICA")==0)||(strcmp(c.marque,"msa")==0)||(strcmp(c.marque,"ica")==0)||(strcmp(c.marque,"hitec")==0) ) )
{
output= lookup_widget (button, "MHlabelmod");
strcpy(ch,"modfication effectuee avec succees");
gtk_label_set_text(GTK_LABEL(output),ch);
modifier_capteur(idold1,c);
}
else
{
output= lookup_widget (button, "MHlabelmod");
strcpy(ch,"verifer le type et le marque ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}
void
on_MHbuttonOk_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *idnv ;
GtkWidget *idold ;
GtkWidget *output ;
GtkWidget *fenetre_modifier;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *max;
GtkWidget *min;
GtkWidget *gaara;
GtkWidget *numero;
GtkWidget *type;
GtkWidget *marque;
char id1[100];
int i = 0 ;
int c ;
cap a ;
char ch[100]="";
char max1[100];
char min1[110];
char gaara1[100];
char jour1[100];
char mois1[100];
char annee1[100];
char numero1[100];


fenetre_modifier = lookup_widget (button, "MHmodifiercapteur");
idold = lookup_widget (button, "MHentrymodifierID");
idnv = lookup_widget (button, "entrymofidiernouvid");
max = lookup_widget (button, "entrymodifiermax");
type = lookup_widget (button, "MHentrytype");
marque = lookup_widget (button, "MHentrymarque");
gaara = lookup_widget (button, "spinbutton8");
jour = lookup_widget (button, "spinbutton5");
mois = lookup_widget (button, "spinbutton6");
annee = lookup_widget (button, "spinbutton7");
min = lookup_widget (button, "entrymodifiermin");
numero = lookup_widget (button, "entrymodifiernumero");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(idold)));
c = chercher_capteur(id1);
if (c == 1)
{
a = find(id1);
sprintf(max1,"%d",a.max);
sprintf(min1,"%d",a.min);
sprintf(numero1,"%d",a.numero);
output = lookup_widget (button, "labelmodifiermes");
strcpy(ch," le capteur existe");
gtk_label_set_text(GTK_LABEL(output),ch);
gtk_entry_set_text(GTK_ENTRY(idnv),a.id);
gtk_entry_set_text(GTK_ENTRY(numero),numero1);
gtk_entry_set_text(GTK_ENTRY(max),max1);
gtk_entry_set_text(GTK_ENTRY(min),min1);
gtk_entry_set_text(GTK_ENTRY(type),a.type);
gtk_entry_set_text(GTK_ENTRY(marque),a.marque);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(gaara),a.gaara);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),a.d.j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),a.d.m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee),a.d.a);
}
else
{
output= lookup_widget (button, "labelmodifiermes");
strcpy(ch," le capteur n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}

void
on_MHradiobuttontemp_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=1;
}


void
on_MHradiobuttoneau_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=2;
}


void
on_MHradiobuttonmove_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=3;
}


void
on_MHradiobuttonfum_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=4;
}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter ;
gchar* id;
int numero ;
gchar* marque ;
gchar* type ;
int max ;
int min ;
int gaara ;
cap c;
int jour ;
int mois ;
int annee ;


GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&marque,2,&numero,3,&type,4,&max,5,&min,6,&gaara,7,&jour,8,&mois,9,&annee,-1);
		strcpy(c.id,id);
		strcpy(c.marque,marque);
		strcpy(c.type,type);
		c.gaara=gaara;
		c.max=max;
		c.min=min;
		c.d.j=jour;
		c.d.m=mois;
		c.d.a=annee;
		c.numero=numero;
		afficher_capteur(treeview);
	}

}




void
on_buttontempajoute_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *jour;
GtkWidget *heure;
GtkWidget *valeur;
GtkWidget *id;
GtkWidget *numero;
GtkWidget *output;
char id1[100];
int val0 ;
char val1[100];
temp p;
int jour0;
int heure0;
char numero1[100];
int numero0;
char ch[100];
int kk;
fenetre_ajout = lookup_widget (button, "MHTEMP");
id = lookup_widget (button, "MHentrytempID");
jour = lookup_widget (button, "MHspintempjour");
heure = lookup_widget (button, "MHspintempheure");
valeur = lookup_widget (button, "entrytempval");
numero = lookup_widget (button, "MHnumero");
jour0=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
heure0=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(heure));
sprintf(numero1,"%d",numero0);
strcpy(numero1, gtk_entry_get_text(GTK_ENTRY(numero)));
sprintf(val1,"%d",val0);
strcpy(val1,gtk_entry_get_text(GTK_ENTRY(valeur)));
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
val0=atoi(val1);
numero0=atoi(numero1) ;
p.jour=jour0 ;
p.heure=heure0 ;
strcpy(p.id,id1) ;
p.numero=numero0 ;
p.valeur=val0 ;
kk = check (numero0,jour0,heure0,id1);
if (kk=0)
{
output = lookup_widget (button, "label28tempajouter");
strcpy(ch," ajoutation effectuee avec succees ");
gtk_label_set_text(GTK_LABEL(output),ch);
ajoute_temp(p) ;
}
else
{
if (kk=1)
{
output = lookup_widget (button, "label28tempajouter");
strcpy(ch," changer l'heure or le jour or le numero du capteur  ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}
}


void
on_MHbutton_affiajou_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;



fenetre_ajout = lookup_widget (button, "MHajoutcapteur");
gtk_widget_destroy(fenetre_ajout);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();
gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

}


void
on_afficherbuttontemp_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *fenetre_temp;


fenetre_afficher = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(fenetre_temp);
fenetre_temp = lookup_widget (button, "MHTEMP");
fenetre_temp = create_MHTEMP();

gtk_widget_show(fenetre_temp);

}


void
on_buttonaffichedecf_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *fenetre_decf;


fenetre_afficher = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(fenetre_decf);
fenetre_decf = lookup_widget (button, "defectueux");
fenetre_decf = create_defectueux();
gtk_widget_show(fenetre_decf);

}


void
on_afficherbuttonajou_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;


fenetre_afficher = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(fenetre_afficher);
fenetre_ajout = lookup_widget (button, "MHajoutcapteur");
fenetre_ajout = create_MHajoutcapteur();

gtk_widget_show(fenetre_ajout);

}


void
on_afficherbuttonsup_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supprimer;
GtkWidget *fenetre_afficher;


fenetre_afficher = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(fenetre_supprimer);
fenetre_supprimer = lookup_widget (button, "MHsupprimercapteur");
fenetre_supprimer = create_MHsupprimercapteur();

gtk_widget_show(fenetre_supprimer);

}


void
on_afficherbuttonmod_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modifier;
GtkWidget *fenetre_afficher;


fenetre_afficher = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(fenetre_modifier);
fenetre_modifier = lookup_widget (button, "MHmodifiercapteur");
fenetre_modifier = create_MHmodifiercapteur();

gtk_widget_show(fenetre_modifier);

}


void
on_MHAFFSUP_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supp;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_supp = lookup_widget (button, "MHsupprimercapteur");

gtk_widget_destroy(fenetre_supp);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);


}


void
on_MHAFFTEMP_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_temp;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;



fenetre_temp = lookup_widget (button, "MHTEMP");

gtk_widget_destroy(fenetre_temp);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

}


void
on_MHRETURNMAIN_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_defec;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;



fenetre_defec = lookup_widget (button, "defectueux");

gtk_widget_destroy(fenetre_defec);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

}


void
on_MHRETURNAJOT_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;

fenetre_afficher = lookup_widget (button, "defectueux");

gtk_widget_destroy(fenetre_afficher);
fenetre_ajout = lookup_widget (button, "MHTEMP");
fenetre_ajout = create_MHTEMP();

gtk_widget_show(fenetre_ajout);


}


void
on_MHVERSAFF_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview2;

char temperature [100];

fenetre_ajout = lookup_widget (button, "MHTEMP");

gtk_widget_destroy(fenetre_ajout);
fenetre_afficher = lookup_widget (button, "defectueux");
fenetre_afficher = create_defectueux();

gtk_widget_show(fenetre_afficher);

treeview2 = lookup_widget(fenetre_afficher,"treeview2");
defective_capture();
afficher_defectueux(treeview2);

}


void
on_MHMODAFF_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_mod;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_mod = lookup_widget (button, "MHsupprimercapteur");

gtk_widget_destroy(fenetre_mod);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);
}


void
on_MHACTUALISER1_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;


w1 = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

gtk_widget_hide(w1);
treeview1 = lookup_widget(fenetre_afficher,"treeview1");
vider(treeview1);
afficher_capteur(treeview1);
}


void
on_MHACTUALISER2_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *defectueux;
GtkWidget *treeview2;


defectueux = lookup_widget (button, "defectueux");
defectueux = create_defectueux();

treeview2 = lookup_widget(defectueux,"treeview2");
choix(f,m,f,d);
afficher_type(treeview2);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter ;
gchar* id;
int numero ;
gchar* marque ;
gchar* type ;
int max ;
int min ;
int gaara ;
cap c;
int jour ;
int mois ;
int annee ;


GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&marque,2,&numero,3,&type,4,&max,5,&min,6,&gaara,7,&jour,8,&mois,9,&annee,-1);
		strcpy(c.id,id);
		strcpy(c.marque,marque);
		strcpy(c.type,type);
		c.gaara=gaara;
		c.max=max;
		c.min=min;
		c.d.j=jour;
		c.d.m=mois;
		c.d.a=annee;
		c.numero=numero;
		afficher_defectueux(treeview);
	}
	}



void
on_MHVERFAJOUTERTEMP_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id ;
GtkWidget *output ;
GtkWidget *output1 ;
char id1[100];
int c ;
char ch [100];
char ch1 [100];
cap a;
char numero[100];
id= lookup_widget (button, "MHentrytempID");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
c = chercher_capteur(id1);
if (c ==-1) 
{
output= lookup_widget (button, "MHlabelverifier");
strcpy(ch," le capteur n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
a = find (id1);
output = lookup_widget (button, "MHlabelverifier");
output1 = lookup_widget (button, "MHlabelnumero");
strcpy(ch,"le capteur existe");
sprintf(numero,"%d",a.numero);
strcpy(ch1,"le max de numero de capteur est : ");
strcat(ch1,numero);
gtk_label_set_text(GTK_LABEL(output),ch);
gtk_label_set_text(GTK_LABEL(output1),ch1);
}

}


void
on_MHbuttonaffiajouter_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHajoutcapteur,*MHaffichercapteur,*treeview1;

GtkWidget *w1;

MHajoutcapteur=lookup_widget(button,"MHajoutcapteur");
MHaffichercapteur=create_MHaffichercapteur();
gtk_widget_show(MHaffichercapteur);


treeview1=lookup_widget(MHaffichercapteur,"treeview1");

afficher_capteur(treeview1);
}


void
on_MHcheckbuttondef_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{t=1;}
else {t=0;}
}


void
on_MHcheckbutton4def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{f=1;}
else {f=0;}
}


void
on_MHcheckbutton5def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{d=1;}
else {d=0;}
}


void
on_MHtomodifier_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHmodifiercapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHmodifiercapteur = lookup_widget (button, "MHmodifiercapteur");
MHmodifiercapteur = create_MHmodifiercapteur();
gtk_widget_show(MHmodifiercapteur);
}

void
on_MHtosupprimer_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHsupprimercapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHsupprimercapteur = lookup_widget (button, "MHsupprimercapteur");
MHsupprimercapteur = create_MHsupprimercapteur();
gtk_widget_show(MHsupprimercapteur);
}


void
on_MHtoajouter_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHajoutcapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHajoutcapteur = lookup_widget (button, "MHajoutcapteur");
MHajoutcapteur = create_MHajoutcapteur();
gtk_widget_show(MHajoutcapteur);
}


void
on_MHtoafficher_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHaffichercapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");
MHaffichercapteur = create_MHaffichercapteur();
gtk_widget_show(MHaffichercapteur);
}


void
on_MHbuttoncapchercher_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id ;
GtkWidget *output ;
char id1[100] ;
int c ;
char ch [100];
id= lookup_widget (button, "entry_rechercher2");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
c = chercher_capteur(id1);
if (c == 1) 
{
output= lookup_widget (button, "label_chercher3");
strcpy(ch," le menu existe ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
output= lookup_widget (button, "label_chercher3");
strcpy(ch," le menu n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);

}
}

void
on_MHbuttondata_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
int k;
char texte[500];
char texte2[500];
char texte3[500];
GtkCalendar *ajc,*output999;
int mois, jour , annee;
guint* day, month, year;
ajc=lookup_widget(button,"MHcalendar1");
output999=lookup_widget(button,"MHlabeldata");
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
jour=year;
mois=month+1;
annee=day;

k=initialisation(jour,mois,annee);
sprintf(texte,"le nombre des etudiants qui \n ont ce date de naissance %d/%d/%d sont :\n %d",jour,mois,annee,k);
//strcpy(texte3,nbrdatee(jour,mois,annee));
//strcpy(texte2,texte3);
gtk_label_set_text(GTK_LABEL(output999),texte);
}


void
on_MHcheckbutton3def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{m=1;}
else {m=0;}
}


void
on_buttonchercherreturn_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHcherchercapteur;
GtkWidget *MHaffichercapteur;

MHcherchercapteur = lookup_widget (button, "MHcherchercapteur");

gtk_widget_destroy(MHcherchercapteur);
MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");
MHaffichercapteur = create_MHaffichercapteur();

gtk_widget_show(MHaffichercapteur);
}


void
on_MHrchercheraff_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHcherchercapteur;
GtkWidget *MHaffichercapteur;

MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(MHaffichercapteur);
MHcherchercapteur = lookup_widget (button, "MHcherchercapteur");
MHcherchercapteur = create_MHcherchercapteur();

gtk_widget_show(MHcherchercapteur);
}


void
on_button_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
 reclamation r;

 GtkWidget *input1, *input2,*input3,*input4,*input5,*input6,*input7;
 GtkWidget *fenetre_ajouter;

fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");

input1=lookup_widget(objet,"entry_id");
input2=lookup_widget(objet,"entry_nom");
input3=lookup_widget(objet,"entry_prenom");
input4=lookup_widget(objet,"entry_type");
input5=lookup_widget(objet,"entry_description");
input6=lookup_widget(objet,"entry_date_reclamation");
input7=lookup_widget(objet,"YM_combobox_heure");



strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(r.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(r.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(r.type,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(r.description,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(r.date_reclamation,gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(r.heure_reclamation,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));

ajouter(r);


}


void
on_button_afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter;
GtkWidget *fenetre_afficher;
GtkWidget *treeview_afficher;

fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");

gtk_widget_destroy(fenetre_ajouter);
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();

gtk_widget_show(fenetre_afficher);

treeview_afficher=lookup_widget(fenetre_afficher,"treeview_afficher");
afficher(treeview_afficher);


}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter,*fenetre_afficher;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
fenetre_ajouter=create_fenetre_ajouter();
gtk_widget_show(fenetre_ajouter);

}


void
on_treeview_afficher_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
 GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* prenom;
	gchar* type;
	gchar* description;
        gchar* date_reclamation;
	reclamation r;

       GtkWidget *pInfo;

   GtkTreeModel *model = gtk_tree_view_get_model(treeview);

 if(gtk_tree_model_get_iter(model,&iter,path))
{   
       //obtention des valeurs de la ligne selectionnée
  gtk_tree_model_get ( GTK_LIST_STORE(model),&iter,0,&id,1,&nom,2,&prenom,3,&type,4,&description,5,&date_reclamation,-1);
       //copie des valeurs dans la variable p de type personne pour le passer a la fonction de suppression
strcpy(r.id,id);
strcpy(r.nom,nom);
strcpy(r.prenom,prenom);
strcpy(r.type,type);
strcpy(r.description,description);
strcpy(r.date_reclamation,date_reclamation);

pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_YES_NO,"Voulez-vous \nsupprimer cet utilisateur?");
switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
{
case GTK_RESPONSE_YES:
gtk_widget_destroy(pInfo);

supprimer(r,"reclamation.txt");
afficher(treeview);

break;
case GTK_RESPONSE_NO:
gtk_widget_destroy(pInfo);

break;
}
}
}
void
on_button_chercher_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id ;
GtkWidget *output ;
char id1[50];
int a ;
char ch [50];
id= lookup_widget (button, "entry_recherche");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
a = recherche(id1);
if (a == 1)
{
output= lookup_widget (button, "labelchercher");
strcpy(ch,"Votre reclamation existe ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else
{
output= lookup_widget (button, "labelchercher");
strcpy(ch," Votre reclamation n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);
}

}
void
on_buttonservice_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *output;
char texte [100];
sercive(texte);
output= lookup_widget (button, "label_service");
gtk_label_set_text(GTK_LABEL(output),texte);


}


void
on_gotoajoute_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter;
GtkWidget *fenetre_afficher;

fenetre_afficher = lookup_widget (button, "fenetre_afficher");

gtk_widget_destroy(fenetre_afficher);
fenetre_ajouter = lookup_widget (button, "fenetre_ajouter");
fenetre_ajouter = create_fenetre_ajouter();

gtk_widget_show(fenetre_ajouter);
}


void
on_gotomodifier_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *YM_fenetreModifier;
GtkWidget *fenetre_afficher;

fenetre_afficher = lookup_widget (button, "fenetre_afficher");

gtk_widget_destroy(fenetre_afficher);
YM_fenetreModifier = lookup_widget (button, "YM_fenetreModifier");
YM_fenetreModifier = create_YM_fenetreModifier();

gtk_widget_show(YM_fenetreModifier);
}


void
on_gotochercher_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_chercher;
GtkWidget *fenetre_afficher;

fenetre_afficher = lookup_widget (button, "fenetre_afficher");

gtk_widget_destroy(fenetre_afficher);
fenetre_chercher = lookup_widget (button, "fenetre_chercher");
fenetre_chercher = create_fenetre_chercher();

gtk_widget_show(fenetre_chercher);
}


void
on_YM_retour_ajout_clicked             (GtkButton       *button,
                                        gpointer         user_data)
                                         
{
GtkWidget *fenetre_chercher,*fenetre_ajouter;
fenetre_chercher=lookup_widget(button,"fenetre_chercher");
gtk_widget_destroy(fenetre_chercher);
fenetre_ajouter=create_fenetre_ajouter();
gtk_widget_show(fenetre_ajouter);

}
void
on_YM_fenetre_ajouter_acceuil_clicked  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter,*YM_acceuil;
YM_acceuil=lookup_widget(button,"YM_acceuil");
gtk_widget_destroy(YM_acceuil);
fenetre_ajouter=create_fenetre_ajouter();
gtk_widget_show(fenetre_ajouter);



}

void
on_YM_fenetre_afficher_acceuil_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher,*YM_acceuil;
YM_acceuil=lookup_widget(button,"YM_acceuil");
gtk_widget_destroy(YM_acceuil);
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);



}

void
on_YM_fenetre_chercher_acceuil_clicked (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_chercher,*YM_acceuil;
YM_acceuil=lookup_widget(button,"YM_acceuil");
gtk_widget_destroy(YM_acceuil);
fenetre_chercher=create_fenetre_chercher();
gtk_widget_show(fenetre_chercher);



}






void
on_YM_DE_AJOUT_VERS_ACCEUIL_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter,*YM_acceuil;
fenetre_ajouter=lookup_widget(button,"fenetre_ajouter");
gtk_widget_destroy(fenetre_ajouter);
YM_acceuil=create_YM_acceuil();
gtk_widget_show(YM_acceuil);



}




void
on_button_af_alarme_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_alarme;


af_alarme=lookup_widget(objet,"af_alarme");

gtk_widget_destroy(af_alarme);
af_alarme=lookup_widget(objet,"af_alarme");
af_alarme=create_af_alarme();

gtk_widget_show(af_alarme);

treeview=lookup_widget(af_alarme,"treeview_alarme");

afficher_alarme(treeview,"alarme.txt");
}


void
on_treeview_hebergement_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gint id;
	etudiant e;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	
}
}


void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_hebergement;


af_hebergement=lookup_widget(objet,"af_hebergement");

gtk_widget_destroy(af_hebergement);
af_hebergement=lookup_widget(objet,"af_hebergement");
af_hebergement=create_af_hebergement();

gtk_widget_show(af_hebergement);

treeview=lookup_widget(af_hebergement,"treeview_hebergement");

afficher_hebergement(treeview,"hebergement.txt");
}





void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *pInfo, *bloc1, *bloc2, *bloc3,*j,*m,*y;
etudiant p;
int a=0;
char ch[20];
FILE *f;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
j=lookup_widget(objet,"mod_J_SK");
m=lookup_widget(objet,"mod_M_SK");
y=lookup_widget(objet,"mod_Y_SK");
bloc1=lookup_widget(objet,"modA");
bloc2=lookup_widget(objet,"modB");
bloc3=lookup_widget(objet,"modC");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));
f = fopen("hebergement.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %s %s %d %d %d %s %d %d %s\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),p.email)!=EOF)
	{
		if(p.id==id){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
gtk_entry_set_text(GTK_ENTRY(mod2),p.prenom);
gtk_entry_set_text(GTK_ENTRY(mod3),p.nom);
strcmp(p.bloc,"A")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc1),TRUE):strcmp(p.bloc,"B")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc2),TRUE):gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc3),TRUE);
gtk_spin_button_set_value(j,p.d.j);
gtk_spin_button_set_value(m,p.d.m);
gtk_spin_button_set_value(y,p.d.a);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4),p.chambre-1);
sprintf(ch,"%d",p.tel);
gtk_entry_set_text(GTK_ENTRY(mod5),ch);
gtk_entry_set_text(GTK_ENTRY(mod6),p.email);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Etudiant introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_modifier_SK_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"af_hebergement");
	window2 = create_mod_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_supp_SK_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"af_hebergement");
	window2 = create_sup_heber();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_ajout_SK_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"af_hebergement");
	window2 = create_aj_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_OK_SK_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *bloc1, *bloc2, *bloc3, *pInfo;
etudiant e;
int c;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
bloc1=lookup_widget(objet,"modA");
bloc2=lookup_widget(objet,"modB");
bloc3=lookup_widget(objet,"modC");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
e.id=atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(mod2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(mod3)));
strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
e.chambre=gtk_combo_box_get_active(GTK_COMBO_BOX(mod4))+1;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(mod5)));
strcpy(e.email,gtk_entry_get_text(GTK_ENTRY(mod6)));
modifier_hebergement(e,"hebergement.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Etudiant modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_aj_SK_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *aj6, *bloc1, *bloc2, *bloc3,*j,*m,*a;
GtkCalendar *ajc;
etudiant e;
int c;
guint day, month, year;
aj1=lookup_widget(objet,"aj1");
aj2=lookup_widget(objet,"aj2");
aj3=lookup_widget(objet,"aj3");

bloc1=lookup_widget(objet,"ajA");
bloc2=lookup_widget(objet,"ajB");
bloc3=lookup_widget(objet,"ajC");
aj4=lookup_widget(objet,"aj4");
aj5=lookup_widget(objet,"aj5");
aj6=lookup_widget(objet,"aj6");
j = lookup_widget(objet,"Aj_J_SK");
m = lookup_widget(objet,"Aj_M_SK");
a = lookup_widget(objet,"Aj_Y_SK");

e.d.j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
e.d.m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
e.d.a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

char id[20];
strcpy(id,gtk_entry_get_text(GTK_ENTRY(aj1)));
e.id = atoi(id);
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(aj2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(aj3)));

strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
c=gtk_combo_box_get_active(GTK_COMBO_BOX(aj4));
e.chambre = c==0?1:c==1?2:3;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(aj5)));
strcpy(e.email,gtk_entry_get_text(GTK_ENTRY(aj6)));
ajouter_hebergement(e,"hebergement.txt");
}




void
on_reMod_SK_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"mod_hebergement");
	window2 = create_af_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_reAj_SK_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"aj_hebergement");
	window2 = create_af_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_del_SK_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *input;
	GtkWidget *output;
	char id[20];
	int id_etudiant ;
	char texte[100];

	input = lookup_widget(objet_graphique,"idSupp_SK");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));

	id_etudiant = atoi(id);
	
	if(idExiste(id_etudiant) == 1){
		supprimer_hebergement(id_etudiant,"hebergement.txt");		
		sprintf(texte,"Votre suppression à été effectué avec succés\n");
		output = lookup_widget(objet_graphique,"suppRes_SK");
    		gtk_label_set_text(GTK_LABEL(output),texte);
		
	}
	else{
		sprintf(texte,"L'id que vous avez saisie n'existe pas\n");
		output = lookup_widget(objet_graphique,"suppRes_SK");
    		gtk_label_set_text(GTK_LABEL(output),texte);	
	}
}


void
on_reSupp_SK_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"sup_heber");
	window2 = create_af_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}












void
on_MT_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_modifid, *MT_modifrole, *MT_modifprenom, *MT_modifnom, *MT_modifmail, *MT_modifniv;
GtkCalendar *MT_modcal;
guint day, month, year;
utilisateur u;
MT_modifid=lookup_widget(objet,"MT_modifid");
MT_modifrole=lookup_widget(objet,"MT_modifrole");
MT_modifprenom=lookup_widget(objet,"MT_modifprenom");
MT_modifnom=lookup_widget(objet,"MT_modifnom");
MT_modifmail=lookup_widget(objet,"MT_modifmail");
MT_modifniv=lookup_widget(objet,"MT_modifniv");
MT_modcal=lookup_widget(objet,"MT_modcal");
u.id=atoi(gtk_entry_get_text(GTK_ENTRY(MT_modifid)));
u.role = gtk_combo_box_get_active(GTK_COMBO_BOX(MT_modifrole))+1;
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(MT_modifprenom)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(MT_modifnom)));
strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(MT_modifmail)));
u.nv = u.role==6?gtk_combo_box_get_active(GTK_COMBO_BOX(MT_modifniv))+1:0;
gtk_calendar_get_date(GTK_CALENDAR(MT_modcal), &year, &month, &day);
u.d.j=day;
u.d.m=month+1;
u.d.a=year;
modifier_utilisateur(u,"utilisateur.txt");
}


void
on_MT_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_modifid, *MT_modifrole, *MT_modifprenom, *MT_modifnom, *MT_modifmail, *MT_modifniv, *msg;
GtkCalendar *MT_modcal;
int a=0;
char ch[20];
FILE *f;
MT_modifid=lookup_widget(objet,"MT_modifid");
MT_modifrole=lookup_widget(objet,"MT_modifrole");
MT_modifprenom=lookup_widget(objet,"MT_modifprenom");
MT_modifnom=lookup_widget(objet,"MT_modifnom");
MT_modifmail=lookup_widget(objet,"MT_modifmail");
MT_modifniv=lookup_widget(objet,"MT_modifniv");
MT_modcal=lookup_widget(objet,"MT_modcal");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(MT_modifid)));
utilisateur p = chercher_utilisateur(id,"utilisateur.txt");
if(p.id!=-1){
gtk_combo_box_set_active(GTK_COMBO_BOX(MT_modifrole),p.role-1);
gtk_entry_set_text(GTK_ENTRY(MT_modifprenom),p.prenom);
gtk_entry_set_text(GTK_ENTRY(MT_modifnom),p.nom);
gtk_entry_set_text(GTK_ENTRY(MT_modifmail),p.email);
gtk_combo_box_set_active(GTK_COMBO_BOX(MT_modifniv),p.role==6?p.nv-1:-1);
gtk_calendar_select_day(GTK_CALENDAR(MT_modcal),g_date_time_new(g_time_zone_new_local(),p.d.j,p.d.m,p.d.a,0,0,0));
}
else{
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Utilisateur introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
}


void
on_treeview_utilisateur_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gint id;
	utilisateur u;
	GtkWidget *msg;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	u.id=id;

	msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_OK_CANCEL,"Voulez-vous vraiment\nsupprimer cet utilisateur?");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	supprimer_utilisateur(u,"utilisateur.txt");
	break;
	case GTK_RESPONSE_CANCEL:
	gtk_widget_destroy(msg);
	break;
	}
	}
}


void
on_MT_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_utilisateur;


af_utilisateur=lookup_widget(objet,"af_utilisateur");

gtk_widget_destroy(af_utilisateur);
af_utilisateur=lookup_widget(objet,"af_utilisateur");
af_utilisateur=create_af_utilisateur();

gtk_widget_show(af_utilisateur);

treeview=lookup_widget(af_utilisateur,"treeview_utilisateur");

afficher_utilisateur(treeview,"utilisateur.txt");
}


void
on_MT_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_ajoutid, *MT_ajoutrole, *MT_ajoutprenom, *MT_ajoutnom, *MT_ajoutmail, *MT_ajoutniv, *h, *f, *MT_j, *MT_m, *MT_a, *check, *msg;
utilisateur u;
guint day, month, year;
MT_ajoutid=lookup_widget(objet,"MT_ajoutid");
MT_ajoutrole=lookup_widget(objet,"MT_ajoutrole");
MT_ajoutprenom=lookup_widget(objet,"MT_ajoutprenom");
MT_ajoutnom=lookup_widget(objet,"MT_ajoutnom");
MT_ajoutmail=lookup_widget(objet,"MT_ajoutmail");
MT_ajoutniv=lookup_widget(objet,"MT_ajoutniv");
MT_j=lookup_widget(objet,"MT_j");
MT_m=lookup_widget(objet,"MT_m");
MT_a=lookup_widget(objet,"MT_a");
h=lookup_widget(objet,"h");
f=lookup_widget(objet,"f");
check=lookup_widget(objet,"check");
u.id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_ajoutid));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(MT_ajoutprenom)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(MT_ajoutnom)));
strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(MT_ajoutmail)));
u.sexe=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(h))?0:1;
u.d.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_j));
u.d.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_m));
u.d.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_a));
u.role = gtk_combo_box_get_active(GTK_COMBO_BOX(MT_ajoutrole))+1;
u.nv = u.role==6?gtk_combo_box_get_active(GTK_COMBO_BOX(MT_ajoutniv))+1:0;
if(gtk_toggle_button_get_active(GTK_CHECK_BUTTON(check)))
ajouter_utilisateur(u,"utilisateur.txt");
else{
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Confirmation requise");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
}


void
on_MT_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_cherid, *MT_cherrole, *MT_cherprenom, *MT_chernom, *MT_chermail, *MT_cherniv, *MT_chersexe, *MT_cherdate, *msg;
char date_naissance[20], sexe[20], role[30], niveau[20];
MT_cherid=lookup_widget(objet,"MT_cherid");
MT_cherrole=lookup_widget(objet,"MT_cherrole");
MT_cherprenom=lookup_widget(objet,"MT_cherprenom");
MT_chernom=lookup_widget(objet,"MT_chernom");
MT_chermail=lookup_widget(objet,"MT_chermail");
MT_chersexe=lookup_widget(objet,"MT_chersexe");
MT_cherdate=lookup_widget(objet,"MT_cherdate");
MT_cherniv=lookup_widget(objet,"MT_cherniv");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(MT_cherid)));
utilisateur p = chercher_utilisateur(id,"utilisateur.txt");
if (p.id==-1){
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"ID introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
else{
sprintf(role,p.role==1?"Admin":p.role==2?"Technicien":p.role==3?"Responsable réclamations":p.role==4?"Agent de foyer":p.role==5?"Agent de restaurant":"Etudiant");
gtk_label_set_text(GTK_LABEL(MT_cherrole),role);
gtk_label_set_text(GTK_LABEL(MT_cherprenom),p.prenom);
gtk_label_set_text(GTK_LABEL(MT_chernom),p.nom);
gtk_label_set_text(GTK_LABEL(MT_chermail),p.email);
sprintf(sexe,p.sexe==0?"Homme":"Femme");
gtk_label_set_text(GTK_LABEL(MT_chersexe),sexe);
sprintf(date_naissance,"%d/%d/%d",p.d.j,p.d.m,p.d.a);
gtk_label_set_text(GTK_LABEL(MT_cherdate),date_naissance);
sprintf(niveau,p.role==6?(p.nv==1?"1ère année":"%déme année"):"Employé",p.nv);
gtk_label_set_text(GTK_LABEL(MT_cherniv),niveau);
}
}




void
on_MT_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj_utilisateur, *af_utilisateur;
af_utilisateur=lookup_widget(objet,"af_utilisateur");
aj_utilisateur=lookup_widget(objet,"aj_utilisateur");
aj_utilisateur=create_aj_utilisateur();
gtk_widget_show(aj_utilisateur);
}


void
on_MT_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod_utilisateur, *af_utilisateur;
af_utilisateur=lookup_widget(objet,"af_utilisateur");
mod_utilisateur=lookup_widget(objet,"mod_utilisateur");
mod_utilisateur=create_mod_utilisateur();
gtk_widget_show(mod_utilisateur);
}


void
on_MT_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *recherche, *af_utilisateur;
af_utilisateur=lookup_widget(objet,"af_utilisateur");
recherche=lookup_widget(objet,"recherche");
recherche=create_recherche();
gtk_widget_show(recherche);
}


void
on_MT_nb_etudiant_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *msg;
char str[1000], ch[1000]="";
strcpy(ch,nombre_etudiant("utilisateur.txt"));
sprintf(str,"%s",ch);
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
























