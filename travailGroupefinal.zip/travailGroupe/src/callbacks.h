#include <gtk/gtk.h>


void
on_MHbutton_ajoute_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonafficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonOk_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHradiobuttontemp_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHradiobuttoneau_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHradiobuttonmove_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHradiobuttonfum_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficherbutton1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbutton2_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbutton3_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbutton4_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttontempajoute_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_MHbutton_affiajou_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttontemp_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichedecf_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttonajou_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttonsup_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttonmod_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHAFFSUP_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHAFFTEMP_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHRETURNMAIN_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHRETURNAJOT_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHVERSAFF_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHMODAFF_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHACTUALISER1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHACTUALISER2_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_MHVERFAJOUTERTEMP_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHVERFAJOUTERTEMP_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHbuttonaffiajouter_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHcheckbuttondef_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHcheckbutton4def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHcheckbutton5def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHtomodifier_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHtosupprimer_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHtoajouter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHtoafficher_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttoncapchercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttondata_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHcheckbutton3def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonchercherreturn_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHrchercheraff_clicked              (GtkButton       *button,
                                        gpointer         user_data);


void
on_button_ajouter_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview_afficher_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);





void
on_YM_recherche_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_YM_service_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonservice_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_gotoajoute_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_gotomodifier_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_gotochercher_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_YM_retour_ajout_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_YM_fenetre_ajouter_acceuil_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_YM_fenetre_afficher_acceuil_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_YM_fenetre_chercher_acceuil_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_YM_DE_AJOUT_VERS_ACCEUIL_clicked    (GtkButton       *button,
                                        gpointer         user_data);




void
on_button_1_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_3_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_4_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_af_alarme_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_hebergement_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_SK_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supp_SK_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajout_SK_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_OK_SK_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_aj_SK_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_SK_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_reMod_SK_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_reAj_SK_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_del_SK_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reSupp_SK_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);












void
on_MT_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_utilisateur_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_MT_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_MT_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_nb_etudiant_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);






