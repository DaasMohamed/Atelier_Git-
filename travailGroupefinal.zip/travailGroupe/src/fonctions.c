#include "fonctions.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gtk/gtk.h>


enum
{
	EID,
	EMARQUE,
	ENUMERO,
	ETYPE,
	EMAX1,
	EMIN1,
	EGAARA,
	EJOUR,
	EMOIS,
	EANNEE,
	COLUMNS


};



void afficher_capteur(GtkWidget *liste)
{
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter  iter;
	GtkListStore   *store;
	char id[100];
	char marque[100];
	int numero ;
	char type[100];
	int max ;
	int min ;
	int gaara ;
	int jour ;
	int mois ;
	int annee ;
	cap c;
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL) 
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);	

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("numero",renderer,"text",ENUMERO,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("max",renderer,"text",EMAX1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("min",renderer,"text",EMIN1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("gaara",renderer,"text",EGAARA,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	}
	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);

f = fopen ("capteur.txt","r");

if(f==NULL)
{
	return;	
}
else
{
	f = fopen ("capteur.txt","a+");
	while(fscanf(f,"%s %s %d %s %d %d %d %d %d %d \n",id,marque,&numero,type,&max,&min,&gaara,&jour,&mois,&annee)!=EOF)
		{ 

		gtk_list_store_append(store,&iter);
		gtk_list_store_set (store,&iter,EID,id,EMARQUE,marque,ENUMERO,numero,ETYPE,type,EMAX1,max,EMIN1,min,EGAARA,gaara,EJOUR,jour,EMOIS,mois,EANNEE,annee,-1);
	
		}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}







int chercher_capteur(char id[])
{ FILE *F ;
int k=0;
cap c;
F=fopen ("capteur.txt","r");
if(F!=NULL){
while (fscanf(F,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,&c.numero,c.type,&c.max,&c.min,&c.gaara,&c.d.j,&c.d.m,&c.d.a)!=(EOF))
{
if (strcmp(id,c.id)==0)
{
k=1;
}
}
}
fclose(F);
return k ;
}

void ajoute_capteur(cap c)
{
FILE *F ;
F =fopen("capteur.txt","a+");
if (F!=NULL)
{
fprintf(F,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,c.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);
fclose(F);
}
else
{
      printf("impossible d'ouvrir le fichier");
    }
}
void supprimer_capteur(char id[])
{
cap c;
FILE *F;
FILE *FICH;

F=fopen("capteur.txt","r");
FICH=fopen("tempcapteur.txt","a+");
while (fscanf(F,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,&c.numero,c.type,&c.max,&c.min,&c.gaara,&c.d.j,&c.d.m,&c.d.a)!=(EOF))
{
if(strcmp(c.id,id)!=0)
{
fprintf(FICH,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,c.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);
}
}
fclose(FICH);
fclose(F);
remove("capteur.txt");
rename("tempcapteur.txt","capteur.txt");
}

void modifier_capteur(char id[],cap ce )
{
FILE *F;
FILE *FICH ;
cap c;
if (chercher_capteur(id)==1)
{
F=fopen("capteur.txt","r");
FICH=fopen("tempcapteur.txt","a+");
while (fscanf(F,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,&c.numero,c.type,&c.max,&c.min,&c.gaara,&c.d.j,&c.d.m,&c.d.a)!=(EOF))
{
if(strcmp(c.id,id)==0)
{
strcpy(c.id,ce.id);
strcpy(c.type,ce.type);
strcpy(c.marque,ce.marque);
c.max=ce.max;
c.min=ce.min;
c.gaara=ce.gaara;
c.d=ce.d;
c.numero=ce.numero;
}
fprintf(FICH,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,c.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);

}
fclose(FICH);
fclose(F);
remove("capteur.txt");
rename("tempcapteur.txt","capteur.txt");
printf("modification effectuee avec succees");

}
else
{
printf("\n l'id de capteur n'existe pas");
}
}
void radio(int radiobutt,char msg[])
{
if(radiobutt ==1)
	strcpy(msg,"temperature");
if(radiobutt ==2)
	strcpy(msg,"debit'd'eau");
if(radiobutt ==3)
	strcpy(msg,"mouvement");
if(radiobutt ==4)
	strcpy(msg,"fumee");
}












void vider(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char id[100];
int jour;
int mois;
int annee;
int max ;
int min ;
int gaara ;
char marque[100];
int numero;
char type[100];
store=NULL;
FILE * f ;
FILE * fich;
store = gtk_tree_view_get_model(liste);
if (store==NULL) 
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);	

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("numero",renderer,"text",ENUMERO,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("max",renderer,"text",EMAX1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("min",renderer,"text",EMIN1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("gaara",renderer,"text",EGAARA,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
    }
	gtk_list_store_append(store,&iter);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
}
///////////////////////////////////////////////////////////////
void ajoute_temp(temp p)
{
FILE *F ;
F =fopen("valeurs.txt","a+");
if (F!=NULL)
{
fprintf(F,"%s %d %d %d %d \n",p.id,p.jour,p.heure,p.numero,p.valeur);
fclose(F);
}
else
{
      printf("impossible d'ouvrir le fichier");
    }
}


void defective_capture()
{
FILE *f ;
FILE *f1 ;
FILE *fich ;
temp p ;
cap c ;
f = fopen("valeurs.txt","r");
f1 = fopen("capteur.txt","r");
fich = fopen("defectueux.txt","a+");
if (f!=NULL)
{
while (fscanf(f1,"%s %s %d %s %d %d %d %d %d %d \n ",c.id,c.marque,&c.numero,c.type,&c.max,&c.min,&c.gaara,&c.d.j,&c.d.m,&c.d.a)!=(EOF))
	{
	while (fscanf(f,"%s %d %d %d %d \n",p.id,&p.numero,&p.jour,&p.heure,&p.valeur)!=(EOF))
	{
		if (((p.valeur>c.max) || (p.valeur<c.min)) &&(strcmp(c.id,p.id)==0))
		{
		fprintf(fich,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,p.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);		
		}	

	}
}
fclose(fich);
fclose(f);
}
else 
{
	printf("impossible d'ouvrir le fichier");
}
}

void afficher_defectueux(GtkWidget *liste1)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store1;
char id[100];
int jour;
int mois;
int annee;
int max ;
int min ;
int gaara ;
char marque[100];
int numero;
char type[100];
cap c;
store1=NULL;
FILE * f ;
store1 =gtk_tree_view_get_model(liste1);
if (store1==NULL) 
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste1),column);	

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" numero",renderer,"text",ENUMERO,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" type",renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" max",renderer,"text",EMAX1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" min",renderer,"text",EMIN1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("gaara",renderer,"text",EGAARA,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste1),column);

	store1 = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
	}
	f = fopen ("defectueux.txt","r");

	if(f==NULL)
	{
		return;	
	}
	else
	{
		f = fopen ("defectueux.txt","a+");
		while(fscanf(f,"%s %s %d %s %d %d %d %d %d %d \n",id,marque,&numero,type,&max,&min,&gaara,&jour,&mois,&annee)!=(EOF))
	{
		gtk_list_store_append(store1,&iter);
		gtk_list_store_set (store1,&iter,EID,id,EMARQUE,marque,ENUMERO,numero,ETYPE,type,EMAX1,max,EMIN1,min,EGAARA,gaara,EJOUR,jour,EMOIS,mois,EANNEE,annee,-1);
	}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste1), GTK_TREE_MODEL (store1));
	g_object_unref (store1);	
	}
}
//////////////////////////////////////////////////////////////
cap find(char id[])
{
FILE *F ;
cap a;
cap c;
F=fopen ("capteur.txt","r");
if(F!=NULL){
while (fscanf(F,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,&c.numero,c.type,&c.max,&c.min,&c.gaara,&c.d.j,&c.d.m,&c.d.a)!=(EOF))
	{
		if (strcmp(c.id,id)==0)
		{	
			a =c ;
		}
	}
}
fclose(F);
return a ;
}

//////////////////////////////////////////////////////////////////////
void choix(int t,int m,int f,int d)
{
FILE *F ;
FILE *g ;
cap c ;
    remove("type.txt");
    f=fopen("defectueux.txt","r");
    g=fopen("type.txt","w+");






 if(F!=NULL)
    {
while(fscanf(F,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,&c.numero,c.type,&c.max,&c.min,&c.gaara,&c.d.j,&c.d.m,&c.d.a)!=(EOF))
	{ 
 	 if ( (t==1) && (strcmp(c.type,"temperature")==0) )
{

	     fprintf(g,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,c.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);
	     
}
 if( (m==1)	&& (strcmp(c.type,"mouvement")==0) )
{

	     fprintf(g,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,c.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);
	     
}
 if  ( (f==1)	&& (strcmp(c.type,"fumee")==0) )
{

	     fprintf(g,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,c.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);
	     
}
 if( (d==1)	&& (strcmp(c.type,"debit'd'eau")==0) )
{

	     fprintf(g,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,c.numero,c.type,c.max,c.min,c.gaara,c.d.j,c.d.m,c.d.a);
	     
}
}
}
fclose(f);
fclose(g);





}

//////////////////////////////////////////////////////

int initialisation(int jour,int mois,int annee)
{
 FILE *F ;
int k=0;
cap c;
F=fopen ("capteur.txt","r");
if(F!=NULL)
{
while (fscanf(F,"%s %s %d %s %d %d %d %d %d %d \n",c.id,c.marque,&c.numero,c.type,&c.max,&c.min,&c.gaara,&c.d.j,&c.d.m,&c.d.a)!=(EOF))
{
if ((c.d.j == jour) && (c.d.m == mois) && (c.d.a == annee)) 
{
k++;
}

}
}
return k;




}
/////////////////////////////////////////////////////////////////
void afficher_type(GtkWidget *liste2)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store2;
char id[100];
int jour;
int mois;
int annee;
int max ;
int min ;
int gaara ;
char marque[100];
int numero;
char type[100];
cap c;
store2=NULL;
FILE * f ;
store2 =gtk_tree_view_get_model(liste2);
if (store2==NULL) 
{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste2),column);	

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" marque",renderer,"text",EMARQUE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" numero",renderer,"text",ENUMERO,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" type",renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" max",renderer,"text",EMAX1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" min",renderer,"text",EMIN1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("gaara",renderer,"text",EGAARA,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",EJOUR,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",EMOIS,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes(" annee",renderer,"text",EANNEE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste2),column);

	store2 = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT, G_TYPE_INT);
	}
	f = fopen ("type.txt","r");

	if(f==NULL)
	{
		return;	
	}
	else
	{
		f = fopen ("type.txt","a+");
		while(fscanf(f,"%s %s %d %s %d %d %d %d %d %d \n",id,marque,&numero,type,&max,&min,&gaara,&jour,&mois,&annee)!=(EOF))
	{
		gtk_list_store_append(store2,&iter);
		gtk_list_store_set (store2,&iter,EID,id,EMARQUE,marque,ENUMERO,numero,ETYPE,type,EMAX1,max,EMIN1,min,EGAARA,gaara,EJOUR,jour,EMOIS,mois,EANNEE,annee,-1);
	}
	fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste2), GTK_TREE_MODEL (store2));
	g_object_unref (store2);	
	}
}



int check(int num,int jour ,int heure,char id [] )
{
temp p;
FILE *f;
int k=0;
f = fopen("valeurs.txt","r");
if (f!=NULL)
{
while (fscanf(f,"%s %d %d %d %d \n",p.id,&p.numero,&p.jour,&p.heure,&p.valeur)!=(EOF))
	{ 
	if ((p.numero == num) && (p.jour == jour) && (p.heure == heure)&& (strcmp(p.id,id )==0 ))
		{
			k=1;
		}


	}
return k;
}
else 
{
return 0;

}
}
