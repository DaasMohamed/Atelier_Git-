#include <gtk/gtk.h>
typedef struct {
	int j ;
	int m ;
	int a ;
}date ;
typedef struct {
	char id[100];
	char marque[100];
	char type[100];
	int max ;
	int min ;
	int gaara ;
	int numero ;
	date d ;
}cap; 
typedef struct {
	char id[100];
	int numero ;	
	int jour ;
	int heure ;
	int valeur ;
}temp;
void ajoute_capteur(cap c);
void supprimer_capteur(char id[]);
void afficher_capteur(GtkWidget *liste);
void modifier_capteur(char id[],cap ce);
int chercher_capteur(char id[]);
void defective_capture(n);
void radio(int radiobutt,char msg[]);
void ajoute_temp(temp p);
void afficher_defectueux(GtkWidget *liste1);
cap find(char id[]);
void choix(int t,int m,int f,int d);
int initialisation(int jour,int mois,int annee);
void afficher_type(GtkWidget *liste2);
int check(int num,int jour ,int heure ,char id[]);
