#include <stdio.h>
{
int a,b;
a=10;
b=3;
printf("_n a=%d b=%d",a,b);
}



